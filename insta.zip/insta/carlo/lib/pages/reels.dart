import 'package:flutter/material.dart';

class UserReels extends StatelessWidget {
  const UserReels ({Key? key}) : super(key : key);

  @override
  Widget build(BuildContext context){
  return const Scaffold(
    body: Center(child: Text('REELS')),
    );
 }
}