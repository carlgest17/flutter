package com.example.carlo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
